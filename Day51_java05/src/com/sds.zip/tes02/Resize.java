package com.sds.tes02;

public interface Resize {
	public abstract void setResize(int size);
}
